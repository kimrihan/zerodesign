jQuery(function ($) {
	//const box = $('input[name="quform_2_52[]"]').val();

	console.log('temp js file');
	//hello();
});
