const allAgreeBtn = document.querySelector('.quform-field-2_52');
console.log(allAgreeBtn);
