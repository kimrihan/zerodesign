<?php

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;


add_action('wp_enqueue_scripts', 'my_theme_enqueue_style_css');

if( !function_exists( 'my_theme_enqueue_style_css') ) :
    function my_theme_enqueue_style_css() {
        
        $parent_style = 'parent-style';

        wp_enqueue_style($parent_style, get_template_directory_uri().'/style.css');
        wp_enqueue_style('child-style', get_stylesheet_directory_uri().'/style.css', array($parent_style), wp_get_theme()->get('Version'));
    }
endif;

wp_enqueue_script('jquery-ui-widget');


add_action('wp_enqueue_scripts', 'ng_enqueue_scripts');
function ng_enqueue_scripts() {

    wp_register_script('logo-request-allcheck', get_stylesheet_directory_uri() . '/assets/js/logo-request-allcheck.js', array(), '1.0.0', true);
    wp_register_style('logo-request-page', get_stylesheet_directory_uri() . '/assets/css/logo-request-page.css');    
    if( is_page('logo') || is_front_page()) {
        wp_enqueue_script('logo-request-allcheck');
        wp_enqueue_style('logo-request-page');
    }

    wp_register_script('singleproduct-qty-cal', get_stylesheet_directory_uri() . '/assets/js/singleproduct-qty-cal.js', array(), '1.0.0', true);
    wp_register_script('ajax-add-to-cart', get_stylesheet_directory_uri() . '/assets/js/ajax-add-to-cart.js', array('jquery'), '1.0.0', true);
    if( function_exists('is_product') && is_product()) {
        wp_enqueue_script('singleproduct-qty-cal');
        wp_enqueue_script('ajax-add-to-cart');
    }
}


// Change add to cart text on single product page
add_filter( 'woocommerce_product_single_add_to_cart_text', 'woocommerce_add_to_cart_button_text_single' );
function woocommerce_add_to_cart_button_text_single() {
    return __( '장바구니 담기', 'woocommerce' );
}

// Change add to cart text on product archives page

add_filter( 'woocommerce_product_add_to_cart_text', 'woocommerce_add_to_cart_button_text_archives' );
function woocommerce_add_to_cart_button_text_archives($label) {
    $label =  __( '장바구니 담기', 'woocommerce' );
    return $label;
}

// Change order button text on checkout page
add_filter('woocommerce_order_button_text', 'woocommerce_order_button_text_change');
function woocommerce_order_button_text_change() {
    return __( '주문하기', 'woocommerce' );
}
add_filter('wc_cart_totals_coupon_label', 'wc_cart_totals_coupon_label_change');
function wc_cart_totals_coupon_label_change() {
    return __('할인', 'woocommerce');
}
/*
add_filter( 'add_to_cart_redirect', 'lw_add_to_cart_redirect');
function lw_add_to_cart_redirect() {
    global $woocommerce;
    $lw_redirect_checkout = $woocommerce->cart->get_checkout_url();

    return $lw_redirect_checkout;
}
*/


/**
 * @snippet WooCommerce Show Product Image @ Checkout Page
 */

add_filter( 'woocommerce_cart_item_name', 'ts_product_image_on_checkout', 10, 3);

function ts_product_image_on_checkout( $name, $cart_item, $cart_item_key ) {
    
    if( !is_checkout() ) {
        return $name;
    }
    
    $_product = apply_filters( 'woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);

    $thumbnail = $_product->get_image();

    $image = '<div class="ts-product-image">'.$thumbnail.'</div>';

    return $image.$name;
}

/**
  * @snippet Woocommerce Show Product Image @ Order-Pay Page
*/
add_filter( 'woocommerce_order_item_name', 'ts_product_image_on_order_pay', 10, 3);

function ts_product_image_on_order_pay($name, $item, $extra) {

    /* Return if not checkout page */

    if( !is_checkout() ) {
        return $name;
    }

   
    $product_id = $item->get_product_id();

    /*get product object */
    $_product = wc_get_product($product_id);

    $thumbnail = $_product->get_image();

    $image = '<div class="ts-product-image">'.$thumbnail.'</div>';

    return $image.$name;


}


function woocommerce_product_category( $args = array() ) {

    $woocommerce_category_id = get_queried_object_id();
    $args = array(
        'parent' => $woocommerce_category_id
    );
    
    //echo '<script>console.dir('.json_encode($args).')</script>';
    $terms = get_terms( 'product_cat', $args);
    
    //echo '<script>console.dir('.json_encode($terms).')</script>';

    if($terms) {
        echo '<ul class="woocommerce-categories">';

        foreach( $terms as $term ) {
            
            echo '<li class="woocommerce-product-category-page">';

            woocommerce_subcategory_thumbnail($term);

            echo '<h2>';

            echo '<a href="'.esc_url(get_term_link($term)).'"class="'.$term->slug.'">';

            echo $term->name;

            echo '</a>';

            echo '</h2>';

            echo '</li>';

        }

        echo '</ul>';
    }

}
add_action( 'woocommerce_before_shop_loop', 'woocommerce_product_category', 100);


// Display Fields
add_action( 'woocommerce_product_options_general_product_data', 'woo_add_custom_fields' );



function woo_add_custom_fields() {
    
    global $woocommerce;
    global $post;

    echo '<div class="options_group">';


    //Text field
    woocommerce_wp_text_input(
        array(
            'id' => '_text_field',
            'label' => __( 'Shipping info', 'woocommerce'),
            'placeholder' => 'Enter your predicted shipping time here',
            'desc_tip' => 'true',
            'description' => __( 'Enter your predicted shipping time here', 'woocommerce' )
        )
        
    );
    echo '</div>';
        
}

// Save Fields
add_action( 'woocommerce_process_product_meta', 'woo_add_custom_fields_save');

function woo_add_custom_fields_save( $post_id ) {

    $woocommerce_text_field = $_POST['_text_field'];
    
    if( !empty( $woocommerce_text_field )) {
        update_post_meta( $post_id, '_text_field', esc_attr( $woocommerce_text_field) );
    }

}

add_action( 'woocommerce_single_product_summary', 'display_custom_field_value', 22 );

function display_custom_field_value() {
    
    $value = get_post_meta( get_the_ID(), '_text_field', true);

    if(strlen($value) != null && strlen($value) > 0) {
        echo '<div class="woocommerce-message">'.get_post_meta( get_the_ID(), '_text_field', true).'</div>';
    }
}
/* 상품 상세 탭 메뉴 추가 */
/*
add_filter( 'woocommerce_product_tabs', 'custom_tab' );

function custom_tab( $tabs ) {

    $tabs['form'] = array(
        'title' => __( 'Send us an enquiry', 'woocommerce' ),
        'priority' => 1,
        'callback' => custom_tab_content 
    );
    return $tabs;
}
*/
/*
function custom_tab_content() {

    echo '<h2>Measurement charts</h2>';
    echo '<p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut fuga eveniet nostrum aliquam dolorum iure doloremque eius hic alias possimus minima ducimus, nihil fugiat atque enim voluptas qui iste. Ratione.</p>';
    echo do_shortcode( '[quform id="1" name="test"]' );
}
*/

/*Remove upsells products from original location */
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );

//create a new custom tab
/*
add_filter( 'woocommerce_product_tabs', 'upsells_product_tab');

function upsells_product_tab( $tabs ) {
    $tabs['upsells-products'] = array(
     'title' => __( 'Compatible products', 'woocommerce'),
     'priority' => 50,
     'callback' => 'upsells_tab_content'   
    );
    return $tabs;
}

function upsell_tab_content() {
    woocommerce_upsell_display();
}
*/

/* Related products IN CUSTOM TAB */

//remove related products form original location
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20);
/*
add_filter( 'woocommerce_product_tabs', 'related_product_tab');

function related_product_tab( $tabs ) {
    $tabs['related-products'] = array(
        'title' => __( 'Related products', 'woocommerce'),
        'priority' => 50,
        'callback' => 'related_product_tab_content'
    );
    return $tabs;
}
*/
/*
function related_product_tab_content() {
    woocommerce_output_related_products();
}
*/


add_filter('kboard_skin_fields', 'my_kboard_skin_fields', 10, 2);
function my_kboard_skin_fields($fields, $board){
    
    if($board->id == '4'){
        
        if(!isset($fields['agree_checkbox'])){
            $fields['agree_checkbox'] = array(
                'field_type' => 'agree_checkbox',
                'field_label' => '개인정보 제공 및 활용 동의',
                'class' => 'kboard-attr-checkbox',
                'hidden' => '',
                'meta_key' => '',
                'field_name' => '',
                'permission' => '',
                'roles' => '',
                'default_value' => '',
                'placeholder' => '',
                'required' => '',
                'show_document' => '',
                'description' => '',
                'close_button' => 'yes'
            );
        }
    }
    
    return $fields;
}

add_filter('kboard_get_template_field_html', 'my_kboard_get_template_field_html', 10, 4);

function my_kboard_get_template_field_html($field_html, $field, $content, $board) 
{
    if($field['field_type'] == 'agree_checkbox') {
        
        ob_start();
        ?>
<div class="kboard-attr-row meta-key-<?php echo esc_attr($field['meta_key'])?> required">
    <label class="attr-name" for="agree_checkbox" style="display:none">
        <span
            class="field-name"><?php echo esc_html($field['field_name'] ? $field['field_name'] : $field['field_label'])?></span>
    </label>
    <div class="attr-value" style="margin:0;">
        <div style="margin: 20px 0; padding: 10px; height: 100px; background-color: #f2f2f2; overflow-y: auto;">
            <p>정보통신망법 규정에 따라 OOO에 회원가입 신청하시는 분께 수집하는 개인정보의 항목, 개인정보의 수집 및 이용목적, 개인정보의 보유 및 이용기간을 안내 드리오니 자세히 읽은 후 동의하여
                주시기 바랍니다.</p>
            <p>1. 수집하는 개인정보</p>
            <p>2. 수집한 개인정보의 이용</p>
            <p>3. 개인정보의 파기</p>
        </div>
        <div style="text-align:center;">
            <input type="hidden" class="required" name="kboard_option_<?php echo esc_attr($field['meta_key'])?>"
                value="1">
            <label><input type="checkbox" class="required"
                    name="kboard_option_<?php echo esc_attr($field['meta_key'])?>" value="1"> 개인정보 제공 및 활용에
                동의합니다.</label>
        </div>
    </div>
</div>
<?php
        $field_html = ob_get_clean();
    }

    return $field_html;
}

/*워드프레스 내장 에디터 사용시 kboard 미디어 추가 버튼 삭제*/

function remove_kboard_add_media_button() {
    remove_action( 'media_buttons', 'kboard_editor_button' );
    remove_filter( 'mce_buttons', 'kboard_register_media_button' );
    remove_filter( 'mce_external_plugins', 'kboard_add_media_button' );
}

add_action( 'kboard_skin_header', 'remove_kboard_add_media_button');


/*woocomerce customization*/
add_action( 'woocommerce_before_main_content', 'woocamp_open_div', 5 );
function woocamp_open_div() {

    /* if we are on a single product page */
    if( !is_product() ) {
        return;
    }

    echo '<div class="woocamp_wrap">';
}


add_action( 'woocommerce_after_main_content', 'woocamp_close_div', 50 );
function woocamp_close_div() {

    if( !is_product() ) {
        return;
    }

    echo '</div>';
}

add_action( 'get_header', 'ng_my_wp_remove_storefront_sidebar' );
function ng_my_wp_remove_storefront_sidebar() {
  
        remove_action( 'storefront_sidebar', 'storefront_get_sidebar', 10);
    
}

// add_action( 'init', 'wc_remove_storefront_breadcrumbs');
// function wc_remove_storefront_breadcrumbs() {
//     remove_action( 'storefront_before_content', 'woocommerce_breadcrumb', 10);
// }

// add_action('woocommerce_after_main_content', 'woocommerce_breadcrumb', 20);

/* 상점 페이지 loop 전 hook*/
/*
add_action( 'woocommerce_before_shop_loop', 'woocamp_add_sale_text', 10);

function woocamp_add_sale_text() {
    echo '<div class="sale-text">';
    echo '<h2>Summer Sale! All hoodies and t-shirts 20% off!</h2>';
    echo '<p>Hurry! Sale ends on August 31st.</p>';
    echo '</div>';
}
*/

/* 상점 페이지 아이템 description 적용 */

add_action( 'woocommerce_after_shop_loop_item', 'woocamp_add_content_after_loop_item', 10);

function woocamp_add_content_after_loop_item() {

    global $product;
   
    /*
    if( $product->is_on_sale() ) {
        echo '<p class="after-loop-item-text">On sale now!</p>';
    } else {
        echo '<p class="after-loop-item-text">Not on sale</p>';
    }
    */
    if ( $product->get_short_description() ) {
        echo '<div class="after-loop-item-description">'.$product->get_short_description().'</div>';
    }
}

/*상품 리스트 장바구니 버튼 제거 */
remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );


/*제품 가격 심볼 변경 */
add_filter( 'woocommerce_currency_symbol', 'change_existing_currency_symbol', 10, 2);

function change_existing_currency_symbol( $currency_symbol, $currency ) {
    switch($currency) {
        case 'KRW' : 
            $currency_symbol = '원';
            break;
    }
    return $currency_symbol;
}

/*
add_filter( 'the_title', 'woocamp_single_product_page_title', 10, 1);

function woocamp_single_product_page_title($title) {
    
    if( ( is_product() && in_the_loop() ) ) {
        $title = '<span class="filtered-title">Woocamp Special</span>'.' - '. $title;

        return $title;
    }

    return $title;
}
*/

/*상품 상세 페이지 총 상품 금액 계산 */
add_action( 'woocommerce_after_add_to_cart_form', 'my_product_price_calculator',10);

function my_product_price_calculator() {

    global $product;


    echo '<div class="total-price-wrapper">';
    echo '<span class="left">총 상품 금액 : </span>';
    echo '<div class="right">';
    echo '<span class="total-price">'.$product->get_price().'</span>';
    echo '<span class="total-price-unit">원</span>';
    echo '<span class="total-price-qty">1</span>';
    echo '</div>';    
    echo '</div>';

}

/*상품 상세 페이지 hook 위치 테스트 */
/*
add_action( 'woocommerce_before_add_to_cart_form', 'my_product_price_calculator_1', 10);

function my_product_price_calculator_1() {
    
    global $product;

    $product_id = $product->get_id();

    $text = get_post_meta($product_id, '_price', true);
    echo $text;
   
    
}
*/

/* 상품 리스트 - 기존의 상품 타이틀 action 제거  */
remove_action('woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10);

/* 상품 리스트 - 타이틀 앞에 'new' 텍스트 추가 상품 별 조건문으로 특정 상품 카테고리 타이틀 수정 가능*/
add_action( 'woocommerce_shop_loop_item_title', 'woocamp_shop_loop_title', 10, 1);

function woocamp_shop_loop_title($title) {

    if( has_term( 'Logo', 'product_cat' ) ) { 
        
        $additinal_text = 'New ';

        echo '<h2 class="woocommerce-loop-product__title">'. '<span class="new">'.$additinal_text.'</span>'.get_the_title().'</h2>';
    
    } else {
       echo '<h2 class="woocommerce-loop-product__title">'.get_the_title().'</h2>';    
    }
}

/*Only show sale products on shop page */
/* 상품 리스트에서 할인 중인 품목만 보여준다 */
/*
add_action( 'woocommerce_product_query', 'woocamp_product_query' );

function woocamp_product_query( $q ) {
    
    $product_ids_on_sale = wc_get_product_ids_on_sale();
    
    $q->set( 'post__in', $product_ids_on_sale ); 
}
*/


/* ajax add-to-cart  */
/*
add_action( 'wp_ajax_ajax_add_to_cart', 'ajax_add_to_cart');

add_action( 'wp_ajax_nopriv_ajax_add_to_cart', 'ajax_add_to_cart');

function ajax_add_to_cart() {

    $product_id = apply_filters('woocommerce_add_to_cart_product_id', absint($_POST['product_id']));
    $quantity = empty($_POST['quantity']) ? 1 : wc_stock_amount($_POST['quantity']);
    $variation_id = absint($_POST['variation_id']);
    $passed_validation = apply_filters('woocommerce_add_to_cart_validation', true, $product_id, $quantity);
    $product_status = get_post_status($product_id);
    
    if($passed_validation && WC()->cart->add_to_cart($product_id, $quantity, $variation_id) && 'publish' === $product_status) {

        do_action('woocommerce_ajax_added_to_cart', $product_id);

        if('yes' === get_option('woocommerce_cart_redirect_after_add')) {
            wc_add_to_cart_message(array($product_id => $quantity), true);
        }

        WC_AJAX :: get_refreshed_fragments();
    } else {

        $data = array(
            'error' => true,
            'product_url' => apply_filters('woocommerce_cart_redirect_after_error', get_permalink($product_id), $product_id),
            
        );

        echo wp_send_json($data);
    }

    wp_die();
}*/

//Add custom message to Woocommerce cart page
/*
add_action( 'woocommerce_before_cart_table', 'shop_message', 20);
function shop_message() {
    echo '<p class="woocommece-message">This is my custom text!!!!!</p>';
}
*/

add_action( 'woocommerce_cart_is_empty', 'empty_cart_message', 1);

function empty_cart_message() {
    echo '<p class="empty-message">장바구니가 비어 있습니다.</p>';
}


add_action( 'woocommerce_after_cart_contents', 'woocommerce_empty_cart_button', 999 );
function woocommerce_empty_cart_button() {
    
    echo '<a href="' . esc_url( add_query_arg( 'empty_cart', 'yes' ) ) . '" class="button cart" title="' . esc_attr( 'emptycart', 'woocommerce' ) . '">' . esc_html( '카트전체비우기', 'woocommerce' ) . '</a>';

}


add_action( 'wp_loaded', 'woocommerce_empty_cart_action', 20);

function woocommerce_empty_cart_action() {
    
    if ( isset( $_GET['empty_cart'] ) && 'yes' === esc_html( $_GET['empty_cart'] ) ) {
       
        WC()->cart->empty_cart();
        
        $referer = wp_get_referer() ? esc_url( remove_query_arg( 'empty_cart') ) : wc_get_cart_url();
        wp_safe_redirect( $referer);
        
    }
}

add_action( 'woocommerce_after_cart_totals', 'button_direct_to_archive', 22);
function button_direct_to_archive() {

    echo '<a href="'.esc_url(get_permalink( get_page_by_title( '로고 제작비용' ))).'">쇼핑 계속하기</a>';

}

add_action( 'wp_footer', 'cart_update_qty_script' ); 
function cart_update_qty_script() { 
    if (is_cart()) : 
    ?>
<script>
jQuery('div.woocommerce').on('change', '.qty', function() {
    jQuery("[name='update_cart']").trigger("click");
});
</script>
<?php 
    endif; 
}

/**
 * Remove all possible fields
 */

 function wc_remove_checkout_fields($fields) {
    //Billing fields
    unset( $fields['billing']['billing_country'] );
    unset( $fields['billing']['billing_state'] );
    unset( $fields['billing']['billing_last_name'] );
    unset( $fields['billing']['billing_address_1'] );
    unset( $fields['billing']['billing_address_2'] );
    unset( $fields['billing']['billing_city'] );
    unset( $fields['billing']['billing_postcode'] );

    return $fields;
}
add_filter('woocommerce_checkout_fields', 'wc_remove_checkout_fields');




 /*주문 완료 후, 인터뷰 작성 페이지로 이동 버튼 */
add_action('woocommerce_after_order_details', 'link_button_to_interview', 10);

function link_button_to_interview($order) {
?>

<section class="woocommerce-link-to-interview">

    <h2 class="woocommerce-order-details__title">상품 인터뷰 작성</h2>
    <div class="link-inner">

        <p class="link-btn-description">고객님의 의뢰 내용에 관한 인터뷰 작성입니다.</p>
        <a class="woocommerce-Button button"
            href="<?php echo esc_url(get_permalink( get_page_by_title( '인터뷰작성' ))); ?>"><?php esc_html_e('인터뷰 작성하기', 'woocommerce'); ?></a>
    </div>

</section>
<?php
}


/*회원정보 수정 시 billing_first_name 업데이트*/

// woocommerce 회원정보 업데이트 hook
/*
add_action( 'woocommerce_save_account_details', 'action_woocommerce_save_account_details', 10, 1);

function action_woocommerce_save_account_details($user_id) {
    $data = get_user_meta($user_id, 'first_name', true);
    echo "<pre>"; print_r( $user_id ); echo "</pre>";
    exit();

    update_user_meta( $user_id, 'billing_first_name', $data );
}
*/

add_action( 'wpmem_post_update_data', 'action_woocommerce_save_account_details', 10, 1);

function action_woocommerce_save_account_details( $fields ) {
    //$data = get_user_meta($user_id, 'first_name', true);
    $data = get_user_meta($fields["ID"], 'first_name', true);
    
    update_user_meta($fields["ID"], 'billing_first_name', $data );
}

/*프로필 페이지 적립 포인트 링크 추가*/
add_filter('wpmem_member_links_args', 'my_member_links_args');

function my_member_links_args( $args ) {
    $woocommerce_myaccount_url = get_permalink(get_option('woocommerce_myaccount_page_id'));
			
   
    $args['rows'][] = '<li class="points"><a href="'.wc_get_endpoint_url('view-log', '', $woocommerce_myaccount_url).'">'.__('적립 포인트', 'cosmosfarm-members').'</a></li>';
			
    
    return $args;
    
}

/*프로필 페이지 아바타 제거 */
add_filter('wpmem_member_links_args', 'my_member_profile_header_args', 999, 1);
function my_member_profile_header_args($args){
	$current_user = wp_get_current_user();
	
	$args['wrapper_before'] = '<div class="cosmosfarm-members-form">';
	$args['wrapper_before'] .= '<div class="profile-header">';
	$args['wrapper_before'] .= '<div class="display-name">'.$current_user->display_name.'</div>';
	$args['wrapper_before'] .= '</div>';
	$args['wrapper_before'] .= '<ul class="members-link">';
	$args['wrapper_after'] = '</ul></div>';
	
	return $args;
}


/*checkout page에 포인트 적용 위치 변경*/
/*
add_action('woocommerce_checkout_order_review', 'additional_checkout_points_apply', 5);
function additional_checkout_points_apply() {
    $public_obj = new Points_Rewards_For_WooCommerce_Public( 'points-rewads-for-woocommerce', '1.0.0' );
    $public_obj->wps_wpr_display_apply_points_checkout();
}
*/
/*
add_action('woocommerce_checkout_before_order_review', 'additional_checkout_points_apply_2', 5);
function additional_checkout_points_apply_2() {
    $public_obj = new Points_Rewards_For_WooCommerce_Public( 'points-rewads-for-woocommerce', '1.0.0' );
    $public_obj->wps_wpr_display_apply_points_checkout();
}
*/
/*
add_action('woocommerce_before_checkout_billing_form', 'additional_checkout_points_apply_2', 5);
function additional_checkout_points_apply_2() {
    $public_obj = new Points_Rewards_For_WooCommerce_Public( 'points-rewads-for-woocommerce', '1.0.0' );
    $public_obj->wps_wpr_display_apply_points_checkout();
}
*/


 add_action('woocommerce_after_single_product', 'wc_additional_html_nonmem_buyconfirm_back', 999);
 function wc_additional_html_nonmem_buyconfirm_back() {
    ?>
<section class="modal modal-section type-confirm nonMember-buynow-confirm-wrap">
    <div class="nonMember-buynow-confirm-inner">
        <button class="btn modal_close">닫기</button>
        <h3 class="confirm-title">비회원으로 구매하시겠습니까?</h3>
        <h5>
            <회원혜택>
        </h5>
        <ul>
            <li><span>가입 이벤트 적립 10000원</span></li>
            <li><span>구매 금액 3% 포인트 적립</span></li>
        </ul>
    </div>
    <div class="controll_btn">
        <button class="btn pink_btn btn_ok">비회원 구매하기</button>
        <a class="link-button-signup"
            href="<?php echo esc_url(get_permalink( get_page_by_title( '회원가입' ))); ?>"><?php esc_html_e('회원가입', 'woocommerce'); ?></a>
    </div>

    <a class="link-button-login"
        href="<?php echo esc_url(get_permalink( get_page_by_title( '로그인' ))); ?>"><?php esc_html_e('로그인', 'woocommerce'); ?></a>
</section>

<?php
}

// add_filter('kboard_list_where', 'my_kboard_list_where', 10, 3);

// function my_kboard_list_where($where, $board_id, $content_list){
// 	if($board_id == '2'){ 
// 		$user_id = get_current_user_id();
// 		if($user_id){
// 			$where .= "AND (`status`='' OR `status` IS NULL) OR `member_uid`='{$user_id}'";
// 		}
// 		else{
// 			$where .= "AND (`status`='' OR `status` IS NULL)";
// 		}
// 	}
// 	return $where;
// }
add_filter('kboard_list_where', 'my_kboard_list_where2', 10, 3);
function my_kboard_list_where2($where, $board_id, $content_list){
	if(in_array($board_id, array('2'))){
    //if($board_id == '1'){ 
		$user_id = get_current_user_id();
		if($user_id){
			$board = new KBoard($board_id);
			if(!$board->isAdmin()){
				$where .= "AND (`status`='' OR `status` IS NULL) OR `member_uid`='{$user_id}'";
			}
            
		}
		else{
			$where .= "AND (`status`='' OR `status` IS NULL)";
		}
	}
	return $where;
}

// add_action( 'admin_init', function () {
//     echo "add_action( 'admin_init', function () {<br>";
 
//     foreach ( $GLOBALS['menu'] as $menu ) {
//         echo "&nbsp;&nbsp;&nbsp;&nbsp;remove_menu_page( '$menu[2]' );<br>";
//     }
 
//     echo "}, PHP_INT_MAX );";
//     exit();
// } );



add_action('admin_init', 'remove_admin_menu');
if (!function_exists('remove_admin_menu')) {
	function remove_admin_menu() {
		
        remove_menu_page( 'index.php' );
        
        remove_menu_page( 'separator1' );
        remove_menu_page('edit.php'); //글 
        remove_menu_page('upload.php'); //미디어              
        remove_menu_page( 'edit.php?post_type=page' ); // 페이지
        
        //remove_menu_page( 'pafw_setting' ); pgall 결제관리
        remove_menu_page( 'edit-comments.php' ); // 댓글
        //remove_menu_page( 'kboard_dashboard' ); // 케이보드
        remove_menu_page( 'kboard_store' ); // 스토어


         //remove_menu_page( 'quform.dashboard' ); // 큐폼
         remove_menu_page( 'separator-woocommerce' ); // 구분선
         //remove_menu_page( 'woocommerce' ); // 우커머스
         //remove_menu_page( 'edit.php?post_type=product' ); // 상품
        // remove_menu_page( 'wc-admin&path=/analytics/overview' ); //분석
        remove_menu_page( 'woocommerce-marketing' ); //마케팅
        remove_menu_page( 'separator-elementor' ); // 구분선
        remove_menu_page( 'elementor' ); //엘레멘토
        remove_menu_page( 'edit.php?post_type=elementor_library' ); // 템플릿
        remove_menu_page( 'separator2' ); // 구분선
        remove_menu_page( 'themes.php' ); // 테마
        remove_menu_page( 'plugins.php' ); // 플러그인
        //remove_menu_page( 'users.php' ); // 사용자

        remove_menu_page( 'tools.php' ); //도구
        remove_menu_page( 'options-general.php' ); //설정
         remove_menu_page( 'cosmosfarm_members_setting' ); //회원가입관리
         remove_menu_page( 'separator-last' ); //구분선
         remove_menu_page( 'premium-addons' ); // premium addons for elementor
         remove_menu_page( 'NinjaFirewall' ); // ninjaFirewall
         remove_menu_page( 'Security Settings' ); //xml-rpc security
         
         }
}

// add_action( 'admin_init', function () {
//     echo '<pre>' . print_r( $GLOBALS[ 'menu' ], true) . '</pre>';
// } );

add_action('admin_init', 'change_admin_menu_label');

function change_admin_menu_label() {
    global $menu;
    global $submenu;
    $menu[5][0] = '결제 관리';
    
    $menu[7][0] = '게시판 관리';
    $menu[9][0] = '고객 문의 관리';
    $menu[11][0] = '쇼핑몰 관리';
    $submenu['woocommerce'][2][0] = '포인트 적립';
    $submenu['woocommerce'][3][0] = '주문취소';
    $submenu['quform.dashboard'][0][0] ='대시보드';
    $submenu['quform.dashboard'][1][0] ='양식';
    $submenu['quform.dashboard'][2][0] ='양식추가';

    $submenu['quform.dashboard'][3][0] ='접수된문의';
    $submenu['quform.dashboard'][4][0] ='도구';
    $submenu['quform.dashboard'][5][0] ='설정';


    //remove_submenu_page( 'options-general.php', 'options-writing.php');  
    //remove_submenu_page('themes.php', 'widgets.php');
    //remove_submenu_page('themes.php', 'customize.php?return=%2Fwp-admin%2F');
    //remove_submenu_page('quform.dashboard', 'quform.forms');
    //remove_submenu_page('quform.dashboard', 'quform.forms&sp=add');
    remove_submenu_page('quform.dashboard', 'quform.help');
    remove_submenu_page('wc-admin&path=/analytics/overview', 'wc-admin&path=/analytics/coupons'); //분석->쿠폰
}

//   add_action( 'admin_menu', function () {
//       echo '<pre>' . print_r( $GLOBALS[ 'submenu' ], true) . '</pre>';
//   } );

add_action('admin_bar_menu', 'change_admin_var_item_label', 999);

function change_admin_var_item_label($wp_admin_bar) {
    $wp_admin_bar->remove_node('wp-logo');
    $wp_admin_bar->remove_node('updates');
    $wp_admin_bar->remove_node('comments');
    $wp_admin_bar->remove_node('new-content');
    $wp_admin_bar->remove_node('quform');
    $wp_admin_bar->remove_node('premium-addons');
    




}

// add_action('admin_init', function(){ echo 'admin_init->'; }); 
// add_action('admin_menu', function(){ echo 'admin_menu->'; });

// add_action('admin_head', 'quform_dashboard_custom_style');
// function quform_dashboard_custom_style() {
//     echo '<style>.qfb-db-row .qfb-db-col:nth-of-type(1){display:none}</style>';
// }