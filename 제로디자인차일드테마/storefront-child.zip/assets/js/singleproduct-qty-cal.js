const inputValueOfQuantity = document.querySelector('.quantity .qty');
const totalPriceQty = document.querySelector('.total-price-wrapper .total-price-qty');

const totalPrice = document.querySelector('.total-price');
const initProductPriceNumber = totalPrice.innerText;

const initProductPriceString = parseInt(initProductPriceNumber).toLocaleString('ko-KR');

totalPrice.textContent = initProductPriceString;

inputValueOfQuantity.addEventListener('change', (e) => {
	console.log(e.target.value);
	console.log(initProductPriceNumber);
	console.log((initProductPriceNumber * e.target.value).toLocaleString('ko-KR'));

	totalPriceQty.textContent = e.target.value;
	totalPrice.textContent = (initProductPriceNumber * e.target.value).toLocaleString('ko-KR');
	//totalPrice.textContent = e.target.value * productPrice;
});
