const allAgreeBtn = document.querySelector('.all-agree-checkbox');

allAgreeBtn.addEventListener('click', function (e) {
	const isChecked = e.target.checked;
	const termsConditionsCheckbox = document.querySelector(
		'.terms-conditions-checkbox'
	);
	const privateInfoCheckbox = document.querySelector(
		'.private-info-checkbox'
	);

	termsConditionsCheckbox.checked = isChecked;
	privateInfoCheckbox.checked = isChecked;
});
